To run the game just simply double click "Bob Launcher.exe", but if you still can not run the game due to an "This application requires a Java Runtime Environment" error, please go to:
		
 - Website: [http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html] to download a suitable Java SE Runtime Environment installer 

 - Alternatively, you can also just double click the attached link: [Java SE Runtime Environment 8 - Downloads.html]